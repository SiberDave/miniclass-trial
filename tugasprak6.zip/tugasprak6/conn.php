<?php

$host = "localhost";
$password = "";
$username = "root";
$database = "pw_m6_219116824"; // dirubah

$conn = mysqli_connect($host, $username, $password, $database);

?>